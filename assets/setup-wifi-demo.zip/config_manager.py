import json
import uos
class ConfigManager:
    def __init__(self):
        self.wifi_config_file = 'wifi_config.json'
        self.mqtt_config_file = 'mqtt_config.json'
    
    def load_wifi_config(self):
        """加载WiFi配置"""
        try:
            with open(self.wifi_config_file, 'r') as f:
                return json.load(f)
        except:
            return None
    
    def save_wifi_config(self, config):
        """保存WiFi配置"""
        with open(self.wifi_config_file, 'w') as f:
            json.dump(config, f)
    
    def load_mqtt_config(self):
        """加载MQTT配置"""
        try:
            with open(self.mqtt_config_file, 'r') as f:
                return json.load(f)
        except:
            # 返回默认配置
            return {
                'server': '',
                'port': 1883,
                'username': '',
                'password': '',
                'client_id': 'esp8266_dht11',
                'publish_topic': 'sensors/dht11',
                'subscribe_topics': ['commands/#']
            }
    
    def save_mqtt_config(self, config):
        """保存MQTT配置"""
        with open(self.mqtt_config_file, 'w') as f:
            json.dump(config, f)
        return True
    def is_configured(self):
        """检查是否已配置"""
        config = self.load_mqtt_config()
        if not config:
            print("123")
            return False
        print(config.get('server', '') != '' and config.get('publish_topic', '') != '')
        return config.get('server', '') != '' and config.get('publish_topic', '') != ''