import network
import machine
import time
import json
import socket
import gc
from config_manager import ConfigManager
from web_config_server import WebConfigServer
from sensor_dht11 import DHT11Sensor
from mqtt_config_server import MqttConfigServer
from mqtt_client import MqttClient
from simple_http_server import SimpleHTTPServer

# 配置参数
BUTTON_PIN = 0           # 按钮连接的GPIO引脚
LED_PIN = 2             # LED指示灯引脚（ESP8266板载LED）
sensorDht11 = None
config_manager = ConfigManager()
mqtt_client = MqttClient(config_manager)
config_server = None


# 初始化硬件
button = machine.Pin(BUTTON_PIN, machine.Pin.IN, machine.Pin.PULL_UP)
led = machine.Pin(LED_PIN, machine.Pin.OUT)
last_publish = 0
# LED状态控制
def led_on():
    """LED常亮"""
    led.value(0)

def led_off():
    """LED熄灭"""
    led.value(1)

def led_blink_fast():
    """LED快闪（AP模式）"""
    led.value(not led.value())

def led_blink_slow():
    """LED慢闪（连接中）"""
    led.value(not led.value())
    time.sleep(0.5)
    
def http_main_program():
    global sensorDht11
    simple_http_server = SimpleHTTPServer(sensorDht11)
    if simple_http_server.start_server(port = 8081):
        print("服务器已启动，手机浏览器访问上面显示的IP地址")
        simple_http_server.run()
def my_main_program():
    global sensorDht11
    global config_manager
    global last_publish
    """你的主程序逻辑"""
    if not config_manager.is_configured():
        print("MQTT未配置，启动配置服务器")
        config_server = MqttConfigServer(config_manager)
        if config_server.start():
            # 保持配置服务器运行直到配置完成
            while not config_manager.is_configured():
                config_server.handle_requests()
                time.sleep(1)
            config_server.stop()
    if mqtt_client.connect():
        print("MQTT已连接，开始发送数据")
        try:
            # 检查并重连MQTT
            if not mqtt_client.check_connection():
                print("MQTT重连中...")
                mqtt_client.connect()
            
            # 检查消息（如果支持）
            if hasattr(mqtt_client, 'check_messages'):
                mqtt_client.check_messages()
            
            # 定时发布数据
            if time.time() - last_publish > 10:  # 10秒发布一次
                print("获取dht数据", end='\r')
                if sensorDht11:
                    sensor_data = sensorDht11.read_data()
                    if not sensor_data is None:
                        if mqtt_client.publish(sensor_data):
                            print("数据发布成功")
                        last_publish = time.time()
                else:
                    print("DHT11传感器未初始化", end='\r')
        except Exception as e:
            print("主循环错误:", e)
    time.sleep(1)
def main():
    print("ESP8266智能配网系统启动...")
    led_off()
    gc.collect()
    global sensorDht11
    global config_manager
    """初始化dht"""
    sensorDht11 = DHT11Sensor(pin_num = 2)
    print("检测启动按钮...")
    time.sleep(0.5)
    webConfigServer = WebConfigServer(config_manager = config_manager)
    webConfigServer.set_main_program(http_main_program)
    webConfigServer.start()
    
    

if __name__ == "__main__":
    main()
