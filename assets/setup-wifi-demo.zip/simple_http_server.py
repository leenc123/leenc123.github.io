import socket
import network
import time
import json
import machine
import gc

# 配置参数
BUTTON_PIN = 0           # 按钮连接的GPIO引脚
LONG_PRESS_TIME = 3000  # 长按时间(毫秒)

# 初始化硬件
button = machine.Pin(BUTTON_PIN, machine.Pin.IN, machine.Pin.PULL_UP)
class SimpleHTTPServer:
    def __init__(self,dht11):
        self.dht11 = dht11
        self.sta_if = network.WLAN(network.STA_IF)
        self.server_socket = None
    
    def start_server(self, port=80):
        """启动API服务器"""
        try:
            addr = socket.getaddrinfo('0.0.0.0', port)[0][-1]
            self.server_socket = socket.socket()
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(addr)
            self.server_socket.listen(5)
            self.server_socket.settimeout(2)
            
            ip = self.sta_if.ifconfig()[0]
            print('API服务器: http://{}:{}'.format(ip, port))
            return True
        except Exception as e:
            print("服务器启动失败:", e)
            return False
    
    def json_response(self, data, status_code=200):
        """返回JSON响应"""
        json_data = json.dumps(data, separators=(',', ':'))  # 紧凑格式
        response = "HTTP/1.1 {} OK\r\n".format(status_code)
        response += "Content-Type: application/json\r\n"
        response += "Access-Control-Allow-Origin: *\r\n"
        response += "Connection: close\r\n"
        response += "\r\n"
        response += json_data
        return response
    
    def handle_request(self, client_socket):
        """处理API请求"""
        try:
            request = client_socket.recv(1024).decode('utf-8')
            if not request:
                return
            
            request_line = request.split('\r\n')[0]
            parts = request_line.split(' ')
            if len(parts) < 2:
                return
                
            method, path = parts[0], parts[1]
            print("API请求: {} {}".format(method, path))
            
            response = ""
            
            if method == 'GET':
                if path == '/dht11':
                    # DHT11数据
                    data = {
                        "sensor": "DHT11",
                        "temperature": 0,
                        "humidity": 0,
                        "unit": "celsius",
                        "status": "success"
                    }
                    if self.dht11:
                        sensor_data = self.dht11.read_data()
                        if not sensor_data is None:
                            data = {
                                    "sensor": "DHT11",
                                    "temperature": sensor_data['temperature'],
                                    "humidity": sensor_data['humidity'],
                                    "unit": "celsius",
                                    "status": "success"
                                }
                                
                    else:
                        print("DHT11传感器未初始化", end='\r')
                    
                    response = self.json_response(data)
                else:
                    # 未知路径
                    data = {
                        "error": "Path not found",
                        "code": 404,
                        "available_paths": [
                            "/dht11",
                            "/device/status", 
                            "/sensors/all"
                        ]
                    }
                    response = self.json_response(data, 404)
            
            elif method == 'POST':
                # 处理POST请求（如果需要）
                data = {
                    "message": "POST received",
                    "method": "POST",
                    "status": "success"
                }
                response = self.json_response(data)
            
            else:
                data = {
                    "error": "Method not allowed",
                    "code": 405
                }
                response = self.json_response(data, 405)
                
            client_socket.send(response.encode('utf-8'))
            
        except Exception as e:
            print("API处理错误:", e)
            error_data = {"error": "Internal error", "message": str(e)}
            error_response = self.json_response(error_data, 500)
            client_socket.send(error_response.encode('utf-8'))
        finally:
            client_socket.close()
    # 按钮检测方法
    def is_button_long_pressed(self):
        """检测按钮是否长按"""
        start_time = time.ticks_ms()
        
        while button.value() == 1:
            if time.ticks_diff(time.ticks_ms(), start_time) > 100:
                return False
            time.sleep_ms(10)
        
        press_start = time.ticks_ms()
        while button.value() == 0:
            if time.ticks_diff(time.ticks_ms(), press_start) > LONG_PRESS_TIME:
                print("检测到长按按钮")
                return True
            time.sleep_ms(10)
        
        return False

    def run(self):
        """运行API服务器"""
        while True:
            try:
                client_socket, addr = self.server_socket.accept()
                self.handle_request(client_socket)
                if time.ticks_ms() % 10000 == 0:
                    gc.collect()
                
                if self.is_button_long_pressed():
                    print("\n检测到长按，进入配网模式")
                    break
            except OSError:
                pass
            except Exception as e:
                print("服务器错误:", e)
            time.sleep(1)
