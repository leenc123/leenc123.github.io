import dht
import machine
import time

class DHT11Sensor:
    def __init__(self, pin_num=2):
        self.pin = machine.Pin(pin_num)
        self.sensor = dht.DHT11(self.pin)
        self.last_read_time = 0
        self.read_interval = 2000  # 2秒读取间隔
        
    def read_data(self):
        """读取传感器数据"""
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, self.last_read_time) < self.read_interval:
            return None
            
        try:
            self.sensor.measure()
            temperature = self.sensor.temperature()
            humidity = self.sensor.humidity()
            self.last_read_time = current_time
            return {
                'temperature': temperature,
                'humidity': humidity,
                'timestamp': current_time
            }
        except Exception as e:
            print("读取传感器失败: %s" %e)
            return None
