import socket
import struct
import time

class SimpleMqttClient:
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.socket = None
        self.connected = False
        self.packet_id = 1
    
    def connect(self):
        """连接MQTT服务器"""
        try:
            config = self.config_manager.load_mqtt_config()
            if not config:
                print("无MQTT配置")
                return False
            
            # 创建socket连接
            self.socket = socket.socket()
            addr = socket.getaddrinfo(config['server'], config['port'])[0][-1]
            self.socket.connect(addr)
            self.socket.settimeout(1.0)
            
            # 发送CONNECT包
            if self._send_connect(config):
                print("MQTT连接成功")
                self.connected = True
                
                # 订阅主题
                if config['subscribe_topic']:
                    self._send_subscribe(config['subscribe_topic'])
                    print("已订阅主题: %s" % config['subscribe_topic'])
                
                return True
            else:
                self.socket.close()
                self.socket = None
                return False
                
        except Exception as e:
            print("MQTT连接失败:", e)
            if self.socket:
                self.socket.close()
                self.socket = None
            self.connected = False
            return False
    
    def _send_connect(self, config):
        """发送MQTT CONNECT包"""
        # 简化版的CONNECT包
        protocol_name = "MQTT"
        protocol_level = 4  # MQTT 3.1.1
        
        # 连接标志
        connect_flags = 0x02  # Clean Session
        if config['username']:
            connect_flags |= 0x80
        if config['password']:
            connect_flags |= 0x40
        
        # 构建CONNECT包
        payload = bytearray()
        
        # 协议名
        payload.extend(struct.pack("!H", len(protocol_name)))
        payload.extend(protocol_name.encode())
        
        # 协议级别
        payload.append(protocol_level)
        
        # 连接标志
        payload.append(connect_flags)
        
        # 保持连接时间（秒）
        payload.extend(struct.pack("!H", 60))
        
        # 客户端ID
        client_id = config['client_id'].encode()
        payload.extend(struct.pack("!H", len(client_id)))
        payload.extend(client_id)
        
        # 用户名（如果有）
        if config['username']:
            username = config['username'].encode()
            payload.extend(struct.pack("!H", len(username)))
            payload.extend(username)
        
        # 密码（如果有）
        if config['password']:
            password = config['password'].encode()
            payload.extend(struct.pack("!H", len(password)))
            payload.extend(password)
        
        # 固定头
        fixed_header = bytearray()
        fixed_header.append(0x10)  # CONNECT包类型
        fixed_header.append(len(payload))
        
        packet = fixed_header + payload
        
        try:
            self.socket.send(packet)
            
            # 等待CONNACK响应
            response = self.socket.recv(4)
            if len(response) >= 4 and response[0] == 0x20:  # CONNACK
                return response[3] == 0x00  # 连接成功
            return False
            
        except Exception as e:
            print("发送CONNECT包失败:", e)
            return False
    
    def _send_subscribe(self, topic):
        """发送SUBSCRIBE包"""
        try:
            self.packet_id += 1
            
            # 构建SUBSCRIBE包
            payload = bytearray()
            
            # Packet ID
            payload.extend(struct.pack("!H", self.packet_id))
            
            # 主题
            topic_bytes = topic.encode()
            payload.extend(struct.pack("!H", len(topic_bytes)))
            payload.extend(topic_bytes)
            
            # QoS级别
            payload.append(0x00)  # QoS 0
            
            # 固定头
            fixed_header = bytearray()
            fixed_header.append(0x82)  # SUBSCRIBE包类型
            fixed_header.append(len(payload))
            
            packet = fixed_header + payload
            self.socket.send(packet)
            
            return True
            
        except Exception as e:
            print("发送SUBSCRIBE包失败:", e)
            return False
    
    def publish(self, data):
        """发布数据"""
        if not self.connected or not self.socket:
            return False
        
        try:
            config = self.config_manager.load_mqtt_config()
            
            # 准备消息
            if isinstance(data, dict):
                import json
                message = json.dumps(data)
            else:
                message = str(data)
            
            message_bytes = message.encode()
            topic_bytes = config['publish_topic'].encode()
            
            # 构建PUBLISH包
            payload = bytearray()
            
            # 主题
            payload.extend(struct.pack("!H", len(topic_bytes)))
            payload.extend(topic_bytes)
            
            # 消息内容
            payload.extend(message_bytes)
            
            # 固定头
            fixed_header = bytearray()
            fixed_header.append(0x30)  # PUBLISH包类型，QoS 0
            fixed_header.append(len(payload))
            
            packet = fixed_header + payload
            self.socket.send(packet)
            
            return True
            
        except Exception as e:
            print("MQTT发布失败:", e)
            self.connected = False
            return False
    
    def check_connection(self):
        """检查连接状态"""
        if not self.connected or not self.socket:
            return False
        
        try:
            # 发送PINGREQ包
            ping_packet = bytes([0xC0, 0x00])  # PINGREQ包
            self.socket.send(ping_packet)
            
            # 等待PINGRESP（简化处理，不严格检查）
            return True
            
        except:
            self.connected = False
            return False
