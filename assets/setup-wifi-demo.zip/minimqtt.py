import socket
import struct
import time

class MiniMQTT:
    def __init__(self, client_id, server, port=1883, user=None, password=None):
        self.client_id = client_id
        self.server = server
        self.port = port
        self.user = user
        self.password = password
        self.sock = None
        self.connected = False
        self.packet_id = 1
    
    def connect(self):
        """连接到MQTT服务器"""
        try:
            # 创建socket连接
            self.sock = socket.socket()
            addr = socket.getaddrinfo(self.server, self.port)[0][-1]
            self.sock.connect(addr)
            self.sock.settimeout(1.0)
            
            # 发送CONNECT包
            if self._send_connect():
                self.connected = True
                print("MQTT连接成功")
                return True
            else:
                self.sock.close()
                self.sock = None
                return False
                
        except Exception as e:
            print("MQTT连接失败:", e)
            if self.sock:
                self.sock.close()
                self.sock = None
            return False
    
    def _send_connect(self):
        """发送MQTT CONNECT包"""
        try:
            # 固定头
            fixed_header = bytes([0x10])  # CONNECT
            
            # 可变头
            protocol_name = b"MQTT"
            protocol_level = 4  # MQTT 3.1.1
            connect_flags = 0x02  # Clean Session
            
            if self.user:
                connect_flags |= 0x80
            if self.password:
                connect_flags |= 0x40
            
            variable_header = (
                struct.pack("!H", len(protocol_name)) +
                protocol_name +
                bytes([protocol_level, connect_flags, 0, 60])  # Keep alive 60秒
            )
            
            # 有效载荷
            payload = (
                struct.pack("!H", len(self.client_id)) + 
                self.client_id.encode()
            )
            
            if self.user:
                payload += struct.pack("!H", len(self.user)) + self.user.encode()
            if self.password:
                payload += struct.pack("!H", len(self.password)) + self.password.encode()
            
            # 计算剩余长度
            remaining_length = len(variable_header) + len(payload)
            fixed_header += self._encode_length(remaining_length)
            
            # 发送完整包
            packet = fixed_header + variable_header + payload
            self.sock.send(packet)
            
            # 等待CONNACK
            response = self.sock.recv(4)
            return len(response) >= 4 and response[0] == 0x20 and response[3] == 0
            
        except Exception as e:
            print("CONNECT失败:", e)
            return False
    
    def _encode_length(self, length):
        """编码剩余长度"""
        encoded = bytearray()
        while length > 0:
            digit = length & 0x7F
            length >>= 7
            if length > 0:
                digit |= 0x80
            encoded.append(digit)
        return encoded
    
    def publish(self, topic, message, qos=0):
        """发布消息"""
        if not self.connected:
            return False
        
        try:
            # 固定头
            publish_flags = 0x30 | (qos << 1)  # PUBLISH + QoS
            fixed_header = bytes([publish_flags])
            
            # 可变头
            topic_encoded = topic.encode()
            variable_header = (
                struct.pack("!H", len(topic_encoded)) +
                topic_encoded
            )
            
            # 有效载荷
            if isinstance(message, str):
                payload = message.encode()
            else:
                payload = str(message).encode()
            
            # 计算剩余长度
            remaining_length = len(variable_header) + len(payload)
            fixed_header += self._encode_length(remaining_length)
            
            # 发送包
            packet = fixed_header + variable_header + payload
            self.sock.send(packet)
            
            return True
            
        except Exception as e:
            print("发布失败:", e)
            self.connected = False
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.sock:
            try:
                self.sock.send(b"\xe0\x00")  # DISCONNECT
                self.sock.close()
            except:
                pass
        self.sock = None
        self.connected = False
