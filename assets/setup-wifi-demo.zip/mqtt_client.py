from minimqtt import MiniMQTT

class MqttClient:
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.client = None
        self.connected = False
    
    def connect(self):
        """连接MQTT服务器"""
        try:
            config = self.config_manager.load_mqtt_config()
            if not config or not config.get('server'):
                print("无MQTT配置")
                return False
            
            self.client = MiniMQTT(
                config['client_id'],
                config['server'],
                port=config.get('port', 1883),
                user=config.get('username'),
                password=config.get('password')
            )
            
            if self.client.connect():
                self.connected = True
                print("MQTT客户端连接成功")
                return True
            else:
                return False
                
        except Exception as e:
            print("MQTT连接失败:", e)
            self.connected = False
            return False
    
    def publish(self, data):
        """发布数据"""
        if not self.connected or not self.client:
            return False
        
        try:
            config = self.config_manager.load_mqtt_config()
            publish_topic = config.get('publish_topic', 'device/data')
            
            if isinstance(data, dict):
                # 简化JSON，减少内存使用
                message = self._dict_to_simple_json(data)
            else:
                message = str(data)
            
            success = self.client.publish(publish_topic, message)
            if success:
                print("数据发布成功")
            return success
            
        except Exception as e:
            print("MQTT发布失败:", e)
            self.connected = False
            return False
    
    def _dict_to_simple_json(self, data):
        """将字典转换为简化的JSON字符串，减少内存使用"""
        items = []
        for key, value in data.items():
            if isinstance(value, (int, float)):
                items.append('"%s":%s' % (key, value))
            else:
                items.append('"%s":"%s"' % (key, value))
        return "{%s}" % ",".join(items)
    
    def check_connection(self):
        """检查连接状态 - 简化版本，只返回当前状态"""
        return self.connected and self.client and self.client.connected
    
    def disconnect(self):
        """断开连接"""
        if self.client:
            self.client.disconnect()
        self.connected = False
