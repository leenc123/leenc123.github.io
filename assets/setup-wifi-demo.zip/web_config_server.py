import gc
import machine
import time
import network
import socket
import json

# 配置参数
BUTTON_PIN = 0           # 按钮连接的GPIO引脚
LED_PIN = 2             # LED指示灯引脚（ESP8266板载LED）
LONG_PRESS_TIME = 3000  # 长按时间(毫秒)

# 初始化硬件
button = machine.Pin(BUTTON_PIN, machine.Pin.IN, machine.Pin.PULL_UP)
led = machine.Pin(LED_PIN, machine.Pin.OUT)

class WebConfigServer:
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.main_program_callback = None
    def set_main_program(self, callback):
        """设置主程序回调函数"""
        self.main_program_callback = callback
    # LED控制方法
    def led_on(self):
        """LED常亮"""
        led.value(0)

    def led_off(self):
        """LED熄灭"""
        led.value(1)

    def led_blink_fast(self):
        """LED快闪（AP模式）"""
        led.value(not led.value())

    def led_blink_slow(self):
        """LED慢闪（连接中）"""
        led.value(not led.value())
        time.sleep(0.5)

    # 按钮检测方法
    def is_button_long_pressed(self):
        """检测按钮是否长按"""
        start_time = time.ticks_ms()
        
        while button.value() == 1:
            if time.ticks_diff(time.ticks_ms(), start_time) > 100:
                return False
            time.sleep_ms(10)
        
        press_start = time.ticks_ms()
        while button.value() == 0:
            if time.ticks_diff(time.ticks_ms(), press_start) > LONG_PRESS_TIME:
                print("检测到长按按钮")
                return True
            time.sleep_ms(10)
        
        return False

    # 配置管理方法
    def save_wifi_config(self, ssid, password):
       
        """保存WiFi配置到文件"""
        config = {
            'ssid': ssid,
            'password': password,
            'configured': True
        }
        
        try:
            self.config_manager.save_wifi_config(config)
            print("WiFi配置已保存")
            return True
        except Exception as e:
            print("保存配置失败:", e)
            return False

    # WiFi连接方法
    def connect_to_wifi(self, ssid, password, timeout=20):
        print("正在连接WiFi: %s" % ssid)
        gc.collect()
        
        sta = network.WLAN(network.STA_IF)
        sta.active(True)
        sta.disconnect()
        time.sleep(1)
        
        connect_start = time.time()
        sta.connect(ssid, password)
        
        while not sta.isconnected():
            self.led_blink_slow()
            if time.time() - connect_start > timeout:
                print("连接超时")
                self.led_off()
                return False
                
        self.led_on()
        print("连接成功!")
        print("IP地址:", sta.ifconfig()[0])
        return True

    # AP模式方法
    def start_ap_mode(self):
        """启动AP配网模式"""
        print("启动AP模式...")
        gc.collect()
        ap = network.WLAN(network.AP_IF)
        ap.active(True)
        ap.config(essid='esp-wifi', authmode=network.AUTH_OPEN)
        
        for _ in range(6):
            self.led_blink_fast()
            time.sleep(0.1)
        
        print("AP模式已启动")
        print("SSID: esp-wifi")
        print("IP地址:", ap.ifconfig()[0])
            
        return ap

    # URL解码方法
    def url_decode(self, s):
        """简单的URL解码函数"""
        result = ""
        i = 0
        while i < len(s):
            if s[i] == '%' and i + 2 < len(s):
                try:
                    # 处理%编码
                    hex_val = s[i+1:i+3]
                    char = chr(int(hex_val, 16))
                    result += char
                    i += 3
                except:
                    result += s[i]
                    i += 1
            elif s[i] == '+':
                # 处理+号（空格）
                result += ' '
                i += 1
            else:
                result += s[i]
                i += 1
        return result

    # 请求解析方法
    def parse_get_params(self, request):
        """解析GET请求参数"""
        print("=== 解析GET请求 ===")
        
        data = {}
        try:
            # 查找URL中的参数部分
            first_line = request.split('\r\n')[0]
            if '?' in first_line:
                # 提取参数部分
                params_str = first_line.split('?')[1].split(' ')[0]
                print("参数字符串:", params_str)
                
                # 解析参数
                pairs = params_str.split('&')
                for pair in pairs:
                    if '=' in pair:
                        key, value = pair.split('=', 1)
                        # URL解码
                        data[key] = self.url_decode(value)
                        print("解析参数: %s = '%s'" % (key, data[key]))
            
            print("最终数据:", data)
            
        except Exception as e:
            print("解析GET参数错误:", e)
        
        return data

    # HTTP响应方法
    def send_simple_response(self, cl, content):
        """发送简单响应，避免内存问题"""
        try:
            response = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nConnection: close\r\n\r\n" + content
            cl.send(response)
            gc.collect()
        except Exception as e:
            print("发送响应错误:", e)

    # HTML页面生成方法
    def get_config_page(self, ap_ip):
        """生成极简配置页面"""
        return """
<html>
<head>
<meta charset="UTF-8">
<title>WiFi配置</title>
<style>
body{font-family:Arial;margin:20px;text-align:center;}
.container{max-width:300px;margin:0 auto;padding:20px;}
input,button{width:100%;padding:10px;margin:5px 0;box-sizing:border-box;}
button{background:#4CAF50;color:white;border:none;}
</style>
</head>
<body>
<div class="container">
<h2>WiFi配置</h2>
<p>设备IP: """ + ap_ip + """</p>
<form method="get" action="/configure">
<input type="text" name="ssid" placeholder="WiFi名称" required>
<input type="password" name="password" placeholder="WiFi密码" required>
<button type="submit">连接</button>
</form>
</div>
</body>
</html>
"""

    def get_success_page(self, ip_addr):
        """生成成功页面"""
        return """
<html>
<head><meta charset="UTF-8"><title>成功</title></head>
<body style="text-align:center;margin:50px;">
<h2 style="color:green;">✓ 配置成功！</h2>
<p>设备重启中...</p>
<p>新IP: """ + ip_addr + """</p>
</body>
</html>
"""

    def get_error_page(self, message):
        """生成错误页面"""
        return """
<html>
<head><meta charset="UTF-8"><title>错误</title></head>
<body style="text-align:center;margin:50px;">
<h2 style="color:red;">""" + message + """</h2>
<a href="/">返回重试</a>
</body>
</html>
"""

    # Web服务器主方法
    def start_web_config_server(self):
        """启动Web配置服务器"""
        ap = self.start_ap_mode()
        
        addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(addr)
        s.listen(1)
        
        print('Web配置服务器已启动，等待连接...')
        
        ap_led_timer = time.time()
        
        while True:
            try:
                gc.collect()
                
                s.settimeout(0.1)
                try:
                    cl, addr = s.accept()
                    print("客户端连接:", addr)
                except OSError:
                    current_time = time.time()
                    if current_time - ap_led_timer > 0.3:
                        self.led_blink_fast()
                        ap_led_timer = current_time
                    continue
                
                cl.settimeout(5.0)
                
                # 接收请求
                request = cl.recv(1024).decode('utf-8')
                print("收到请求:", request.split('\r\n')[0] if request else "空请求")
                
                if 'GET /configure' in request:
                    # 解析GET参数
                    form_data = self.parse_get_params(request)
                    ssid = form_data.get('ssid', '')
                    password = form_data.get('password', '')
                    
                    print("收到配置请求 - SSID: %s" % ssid)
                    
                    if ssid:
                        if self.connect_to_wifi(ssid, password):
                            if self.save_wifi_config(ssid, password):
                                sta_ip = network.WLAN(network.STA_IF).ifconfig()[0]
                                self.send_simple_response(cl, self.get_success_page(sta_ip))
                                cl.close()
                                time.sleep(2)
                                machine.reset()
                            else:
                                self.send_simple_response(cl, self.get_error_page("保存配置失败"))
                                cl.close()
                        else:
                            self.send_simple_response(cl, self.get_error_page("连接失败，请检查密码"))
                            cl.close()
                    else:
                        self.send_simple_response(cl, self.get_error_page("SSID不能为空"))
                        cl.close()
                
                else:
                    # 显示配置页面
                    self.send_simple_response(cl, self.get_config_page(ap.ifconfig()[0]))
                    cl.close()
                    
            except Exception as e:
                print("Web服务器错误:", e)
                try:
                    cl.close()
                except:
                    pass
                gc.collect()

    # 主启动方法
    def start(self):
        if self.is_button_long_pressed():
            print("进入配网模式")
            self.start_web_config_server()
            return
        
        config = self.config_manager.load_wifi_config()
        if config:
            print("找到保存的配置，尝试自动连接...")
            if self.connect_to_wifi(config['ssid'], config['password']):
                print("自动连接成功！进入主程序")
                
                while True:
                    print("设备正常运行中...", end='\r')
                    if self.main_program_callback:
                        self.main_program_callback()
                    if time.ticks_ms() % 10000 == 0:
                        gc.collect()
                    
                    if self.is_button_long_pressed():
                        print("\n检测到长按，进入配网模式")
                        self.start_web_config_server()
                        break
                        
                    time.sleep(1)
            else:
                print("自动连接失败，进入配网模式")
                self.start_web_config_server()
        else:
            print("未找到配置，进入配网模式")
            self.start_web_config_server()
