import socket
import network

class MqttConfigServer:
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.config = self.config_manager.load_mqtt_config()
        if not self.config:
            self.config = self.config_manager.default_config.copy()
        self.server_socket = None
    
    def start(self):
        """启动MQTT配置服务器"""
        try:
            addr = socket.getaddrinfo('0.0.0.0', 8080)[0][-1]
            self.server_socket = socket.socket()
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(addr)
            self.server_socket.listen(1)
            self.server_socket.settimeout(0.5)
            
            sta = network.WLAN(network.STA_IF)
            ip = sta.ifconfig()[0] if sta.isconnected() else '192.168.4.1'
            print('MQTT配置: http://%s:8080' % ip)
            return True
        except Exception as e:
            print("配置服务器启动失败:", e)
            return False
    
    def stop(self):
        """停止配置服务器"""
        if self.server_socket:
            self.server_socket.close()
            self.server_socket = None
    
    def handle_requests(self):
        """处理HTTP请求"""
        if not self.server_socket:
            return
        
        try:
            client_socket, addr = self.server_socket.accept()
            client_socket.settimeout(1.0)  # 增加超时时间
            
            # 先读取头部
            request = b""
            header_found = False
            
            # 读取直到找到头部结束标记
            while not header_found:
                chunk = client_socket.recv(256)
                if not chunk:
                    break
                request += chunk
                if b'\r\n\r\n' in request:
                    header_found = True
                if len(request) > 2048:  # 限制头部大小
                    break
            
            if not request:
                client_socket.close()
                return
                
            request_str = request.decode('utf-8', 'ignore')
            
            # 如果是POST请求，读取完整的body
            if request_str.startswith('POST'):
                # 获取Content-Length
                content_length = 0
                for line in request_str.split('\r\n'):
                    if line.lower().startswith('content-length:'):
                        try:
                            content_length = int(line.split(':')[1].strip())
                            break
                        except:
                            pass
                
                print("Content-Length: %s" %content_length)
                
                # 读取剩余的数据
                header_end = request.find(b'\r\n\r\n')
                body_received = len(request) - (header_end + 4)
                
                while body_received < content_length:
                    chunk = client_socket.recv(256)
                    if not chunk:
                        break
                    request += chunk
                    body_received += len(chunk)
                    if len(request) > 4096:  # 总请求大小限制
                        break
                
                request_str = request.decode('utf-8', 'ignore')
                response = self.handle_post(request_str, request)
            else:
                response = self.handle_get()
            
            if isinstance(response, str):
                response = response.encode('utf-8')
            
            client_socket.send(response)
            client_socket.close()
            
        except OSError:
            pass
        except Exception as e:
            print("配置请求错误:", e)
    
    def handle_get(self):
        """返回极简配置页面"""
        html = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
        html += "<h3>MQTT配置</h3>"
        html += "<form method=post>"
        html += "服务器:<br><input name=server value='{}'><br>".format(self.config.get('server', ''))
        html += "端口:<br><input name=port value='{}'><br>".format(self.config.get('port', 1883))
        html += "客户端ID:<br><input name=client_id value='{}'><br>".format(self.config.get('client_id', ''))
        html += "用户名:<br><input name=username value='{}'><br>".format(self.config.get('username', ''))
        html += "密码:<br><input type=password name=password value='{}'><br>".format(self.config.get('password', ''))
        html += "订阅主题:<br><input name=subscribe_topic value='{}'><br>".format(self.config.get('subscribe_topic', ''))
        html += "发布主题:<br><input name=publish_topic value='{}'><br>".format(self.config.get('publish_topic', ''))
        html += "<button type=submit>保存</button>"
        html += "</form>"
        return html
    
    def handle_post(self, request_str, request_bytes):
        """处理配置保存"""
        try:
            print("收到POST请求")
            
            # 查找POST数据的开始位置
            header_end = request_str.find('\r\n\r\n')
            if header_end == -1:
                return self._error_response("无效请求格式")
            
            # 获取POST数据
            post_data = request_str[header_end + 4:]
            print("原始POST数据:", repr(post_data))
            
            if not post_data:
                return self._error_response("没有提交数据")
            
            # 解析标准URL编码格式 (server=192.168.1.166&port=1883...)
            params = {}
            pairs = post_data.split('&')
            
            for pair in pairs:
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    # URL解码
                    value = value.replace('+', ' ')
                    params[key] = value
            
            print("解析的参数:", params)
            
            # 验证必要字段
            required = ['server', 'port', 'client_id', 'publish_topic']
            missing = []
            for field in required:
                if field not in params or not str(params[field]).strip():
                    missing.append(field)
            
            if missing:
                return self._error_response("缺少字段: " + ','.join(missing))
            
            # 验证端口
            try:
                port = int(params['port'])
                if not (1 <= port <= 65535):
                    return self._error_response("端口无效")
            except:
                return self._error_response("端口必须是数字")
            
            # 更新配置
            self.config.update({
                'server': str(params['server']).strip(),
                'port': port,
                'client_id': str(params['client_id']).strip(),
                'username': str(params.get('username', '')).strip(),
                'password': str(params.get('password', '')).strip(),
                'subscribe_topic': str(params['subscribe_topic']).strip(),
                'publish_topic': str(params['publish_topic']).strip()
            })
            
            print("更新后的配置:", self.config)
            
            # 保存配置
            if self.config_manager.save_mqtt_config(self.config):
                return self._success_response()
            else:
                return self._error_response("保存失败")
            
        except Exception as e:
            print("配置保存错误:", e)
            return self._error_response("处理错误: " + str(e))
    
    def _success_response(self):
        """成功响应"""
        html = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
        html += "<h4>保存成功!</h4>"
        html += "<p>3秒后自动返回...</p>"
        html += "<a href='/'>立即返回</a>"
        html += "<meta http-equiv='refresh' content='3;url=/'>"
        return html
    
    def _error_response(self, message):
        """错误响应"""
        html = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
        html += "<h4>错误: {}</h4>".format(message)
        html += "<a href='/'>返回重试</a>"
        return html
